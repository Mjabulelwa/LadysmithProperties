﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace LadysmithProperties.Model
{
    public class Tenant
    {
        public int TenantId { get; set; }

        [DisplayName("First name")]
        [Required(ErrorMessage = "Enter a first name")]
        public string TenantName { get; set; }

        [DisplayName("LastName")]
        [Required(ErrorMessage = "Enter your last name")]
        public string TenantLastName { get; set; }

        [Required(ErrorMessage = "Enter your initials")]
        public string Initials { get; set; }

        [Required(ErrorMessage = "Enter your Email")]
        public string Email { get; set; }


    }
}
