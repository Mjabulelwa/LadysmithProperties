﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LadysmithProperties.Model
{
    public class Renting
    {
        public int RentingId { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        [DisplayName("Renting Price")]
        public decimal Price { get; set; }

        [DisplayName("Check in date")]
        [Required]
        public DateTime MoveInDate { get; set; }

        [DisplayName("Check out date")]
        [Required]
        public DateTime MoveOutDate { get; set; }

    }
}
