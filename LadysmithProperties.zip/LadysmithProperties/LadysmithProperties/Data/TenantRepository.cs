﻿using LadysmithProperties.Model;
using LadysmithProperties.Data;

namespace LadysmithProperties.Data
{
    public class TenantRepository : ITenantRepository
    {
        private readonly AppDbContext _appDbContext;

        public TenantRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public void AddTenant(Tenant tenant)
        {
            _appDbContext.Tenants.Add(tenant);
        }

        public void DeleteTenant(Tenant tenant)
        {
            _appDbContext.Tenants.Remove(tenant);
        }

        public IQueryable<Tenant> GetAllTenants()
        {
            return _appDbContext.Tenants;
        }

        public Tenant GetTenantById(int id)
        {
            return _appDbContext.Tenants.FirstOrDefault(t => t.TenantId == id);
        }

        public void SaveChanges()
        {
            _appDbContext.SaveChanges();
        }

        public void UpdateTenant(Tenant tenant)
        {
            _appDbContext.Tenants.Update(tenant);
        }
    }
}
