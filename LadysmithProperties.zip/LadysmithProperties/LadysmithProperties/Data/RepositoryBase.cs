﻿
using System.Linq.Expressions;
namespace LadysmithProperties.Data
{
    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T : class
    {
        protected AppDbContext _appDBContext;

        public RepositoryBase(AppDbContext appDBContext)
        {
            _appDBContext = appDBContext;
        }
        public void create(T entity)
        {
            _appDBContext.Set<T>().Add(entity);
        }

        public void delete(T entity)
        {
            _appDBContext.Set<T>().Remove(entity);
        }

        public IEnumerable<T> FindAll()
        {
            return _appDBContext.Set<T>();
        }

        public IEnumerable<T> FindByCondition(Expression<Func<T, bool>> expression)
        {
            return _appDBContext.Set<T>().Where(expression);
        }

        public T GetById(int id)
        {
            return _appDBContext.Set<T>().Find(id);
        }

        public void Update(T entity)
        {
            _appDBContext.Set<T>().Update(entity);
        }
    }
}
namespace LadysmithProperties.Data
{
    public class RepositoryBase
    {
    }
}
