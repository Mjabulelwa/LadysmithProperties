﻿using LadysmithProperties.Model;

namespace LadysmithProperties.Data
{
    public interface ITenantRepository
    {
        IQueryable<Tenant> GetAllTenants();
        Tenant GetTenantById(int id);
        void AddTenant(Tenant tenant);
        void UpdateTenant(Tenant tenant);
        void DeleteTenant(Tenant tenant);
        void SaveChanges();
    }
}
