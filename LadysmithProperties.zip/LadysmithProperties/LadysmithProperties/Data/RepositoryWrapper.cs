﻿using LadysmithProperties.Data;

namespace LadysmithProperties.Data
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private AppDbContext _appDbContext;
        private ITenantRepository _Tenant;
        public RepositoryWrapper(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public ITenantRepository Tenant
        {
            get
            {
                if (_Tenant == null)
                {
                    _Tenant = new TenantRepository(_appDbContext);
                }
                return _Tenant;
            }
        }

        public void Save()
        {
            _appDbContext.SaveChanges();
        }
    }
}

